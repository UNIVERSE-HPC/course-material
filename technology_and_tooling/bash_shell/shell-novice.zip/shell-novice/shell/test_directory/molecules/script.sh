head $2 $1
tail -n $3 $1
